<div class="container">
    <h2 class="text-success text-center">Add Form <?php echo e(csrf_field()); ?>        </h2>
    <form method="get" action="/Myrha/myproject/public/create-action/" >
    
    <div class="mb-3">        
        <label for="email" class="form-label">Email address</label>
        <input type="email" class="form-control" id="email"  name="email" aria-describedby="email">
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div id="email" class="form-text text-warning">We'll never share your email with anyone else.</div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>       
    </div>       
    <div class="mb-3">
        <label for="password" class="form-label">Password</label>
        <input type="password" class="form-control" name="password"  id="password">
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div id="email" class="form-text text-warning">We'll never share your password with anyone else.</div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>       
    </div>  
    <button type="submit" class="btn btn-primary">Create Query</button>
    </form>
</div><?php /**PATH /var/www/vhosts/myrah.ikf.in/httpdocs/Myrha/myproject/resources/views/create.blade.php ENDPATH**/ ?>