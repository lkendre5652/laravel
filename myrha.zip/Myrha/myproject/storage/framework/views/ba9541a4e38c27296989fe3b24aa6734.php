<div class="container">
<table class="table table-primary table-hover" >
<tr >
  <th class="table-primary">ID</th>
  <th class="table-secondary">Name</th>
  <th class="table-success">Created At</th>  
  <th class="table-success">Updated At</th>  
  <th class="table-success">Action</th>
</tr>
<?php $__currentLoopData = $Arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
  <td class="table-primary"><?php echo e($todo->id); ?></td>
  <td class="table-secondary"><?php echo e($todo->name); ?></td>
  <td class="table-success"><?php echo e($todo->created_at); ?></td>  
  <td class="table-success"><?php echo e($todo->updated_at); ?></td>  
  <td class="table-success" >
  <a href="/todo-create/" class="text-success">Create</a>
    <a href="todo-remove/<?php echo e($todo->id); ?>" class="text-danger" >Remove</a>
    <span class="text-warning">|</span>
    <a href="/todo-update/<?php echo e($todo->id); ?>" class="text-success">Update</a>
  </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>
</div><?php /**PATH D:\laravel\myproject\resources\views/todo.blade.php ENDPATH**/ ?>